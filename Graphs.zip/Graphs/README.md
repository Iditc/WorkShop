# Intelici Challenge

In this challenge you'll be classifying graphs, which is the basis for the work we do at Intelici.

This is a binary classification challenge with 992 graphs in the training set, and 121 in the test set. In order to extract graph features, you may use all algorithms and functions that networkx (or any other library) provides you, or write your own.

We don't have the ground truth for this data. Instead, four annotators with different skill levels tagged the data, so you'll need to find a way to obtain labels to use for training.

The purpose of this challenge is to see how you work. Writing clean and orderly code and demonstrating understanding is more important than receiving perfect results.

# Layout
- graphs/ contains 1113 graph files in edge list format
- classes_train.csv contains 5 columns: Graph filename, Annotator 1, Annotator 2, Annotator 3, Annotator 4
- classes_test.csv contains 2 columns: Graph filenae, class
